package hello;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Map;

@Controller
public class SitesController {

    @RequestMapping("/welcome")
    public String welcome(Map<String,Object> model) {
        model.put("message", "QC rules!");
        return "welcome";
    }

}
