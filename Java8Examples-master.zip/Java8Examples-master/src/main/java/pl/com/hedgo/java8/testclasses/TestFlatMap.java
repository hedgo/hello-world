package pl.com.hedgo.java8.testclasses;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class TestFlatMap {

    public static void main(String[] args) {

        Stream<List<String>> namesComplicated = Stream.of(
                Arrays.asList("aa","bb"),
                Arrays.asList("cc"),
                Arrays.asList("dd","bb")
        );

        Stream<String> namesFlat = namesComplicated.flatMap(strList -> strList.stream());

        namesFlat.collect(Collectors.toSet()).forEach(System.out::println);

        System.out.println();

        Stream<String> myStream = Stream.of("ddd","cc1","ss","aaaa","111","cc22222");

        Optional<String> wynik = myStream.filter(x->x.startsWith("cc")).findFirst();

        System.out.println(wynik);

        if (wynik.isPresent()) {
            System.out.println(wynik.get());
        }




    }
}
