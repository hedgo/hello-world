package pl.com.hedgo.java8.testclasses;

import pl.com.hedgo.java8.model.Developer;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class TestGroupCountSort {

    public static final List<String> animalsList = Arrays.asList("cat", "dog", "cat", "cat", "eagle", "dog", "eagle", "snake");

    public static final List<Developer> developersList = Arrays.asList(
            new Developer("dev1", new BigDecimal("70000"), 33),
            new Developer("dev2", new BigDecimal("170000"), 40),
            new Developer("dev3", new BigDecimal("170000"), 42),
            new Developer("dev4", new BigDecimal("270000"), 100));


    public void execute() {

        newline("1, super grupowanie w java a nie oracle:)");
        Map<String, Long> result = animalsList.stream().collect(
                Collectors.groupingBy(Function.identity(), Collectors.counting())
        );
        System.out.println(result);

        //newline("2");
        //Map<String, Long> result2 = developersList.stream().collect(
        //        Collectors.groupingBy(Developer::getAge, Collectors.summarizingDouble(Developer::getMoneyLong)));


        newline("2, super, rozbija na podlisty!!");
        Map<BigDecimal,List<Developer>> groupByMoneyMap =
                developersList.stream().collect(Collectors.groupingBy(Developer::getMoney));
        System.out.println(groupByMoneyMap);


        ///////////////////////////////
        //3 apple, 2 banana, others 1
        List<Item> items = Arrays.asList(
                new Item("apple", 10, new BigDecimal("9.99")),
                new Item("banana", 20, new BigDecimal("19.99")),
                new Item("orang", 10, new BigDecimal("29.99")),
                new Item("watermelon", 10, new BigDecimal("29.99")),
                new Item("papaya", 20, new BigDecimal("9.99")),
                new Item("apple", 10, new BigDecimal("9.99")),
                new Item("banana", 10, new BigDecimal("19.99")),
                new Item("apple", 20, new BigDecimal("9.99"))
        );

        Map<String, Long> counting = items.stream().collect(
                Collectors.groupingBy(Item::getName, Collectors.counting()));
        System.out.println(counting);

        Map<String, List<Item>> counting2 = items.stream().collect(Collectors.groupingBy(Item::getName));
        System.out.println("Lista="+counting2);

        Map<String, Integer> sum = items.stream().collect(
                Collectors.groupingBy(Item::getName, Collectors.summingInt(Item::getQty)));

        System.out.println(sum);

    }

    public void newline(String line) {
        System.out.println("\n_____________" + line + "_____________");
    }

    public static void main(String[] args) {
        (new TestGroupCountSort()).execute();
    }
}
