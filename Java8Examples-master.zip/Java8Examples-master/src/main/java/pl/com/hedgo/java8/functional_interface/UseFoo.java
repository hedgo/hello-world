package pl.com.hedgo.java8.functional_interface;

//Based on: https://www.baeldung.com/java-8-lambda-expressions-tips

public class UseFoo {

    public static String addText(String string, Integer myint, Foo foo)
    { return  foo.method(string, myint); }

    public static void main(String[] args) {

        //1. Lambda
        Foo foo = (p, i) -> p + " added from lambda, number="+i;
        String result = UseFoo.addText("Andrew", 5, foo);
        System.out.println(result);

        //2. Classic interface
        foo = new Foo() {
            @Override
            public String method(String string, Integer myint) {
                return string + " added from classic interface, number="+myint;
            }
        };
        result = UseFoo.addText("Andrew", 10, foo);
        System.out.println(result);

        //3. Mozna jeszcze wcale nie uzywac interfejsu Foo ale funkcja wtedy chyba musi miec tylko jeden parametr..
        //Function<String, String> fn = parameter -> parameter + " from lambda";
        //String result = useFoo.addText("Message ", fn);

        //4. Default method in interface
        System.out.println(foo.methodDefault("Bartek"));

        //5. Static z interfejsu, nice:)
        System.out.println(Foo.methodStatic("BBB"));
    }
}
