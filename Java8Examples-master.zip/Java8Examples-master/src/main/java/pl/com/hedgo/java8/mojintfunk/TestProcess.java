package pl.com.hedgo.java8.mojintfunk;

public class TestProcess {

    public static void main(String[] args) {

        //1. Klasycznie (przesylam zachowanie)
        mojametoda("Andrzej ", 100, new Process() {
            @Override
            public String wykonaj(String text, Integer myint) {
                return text + myint;
            }
        });

        //2. Lambda (przesylam zachowanie)
        mojametoda("Andrzej ", 100, (text, myint) -> text + myint);

        //3. Referencja metody (przesylam zachowanie)
        mojametoda("Andrzej ", 100, TestProcess::polacz);

    }

    private static void mojametoda(String text, Integer myint, Process process) {
        System.out.println(process.wykonaj(text, myint));
    }

    private static String polacz(String text, Integer myint) {
        return text + myint;
    }
}
