package pl.com.hedgo.java8.testclasses;

import pl.com.hedgo.java8.model.Developer;
import pl.com.hedgo.java8.model.Human;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class TestStream {


    public static void main(String[] args) {
        new TestStream().execute();
    }

//    public static final List<Developer> developersList = Arrays.asList(
//            new Developer("dev1", new BigDecimal("70000"), 33),
//            new Developer("dev2", new BigDecimal("170000"), 40),
//            new Developer("dev3", new BigDecimal("270000"), 100));

    public void execute() {

        final List<Developer> developersList = Arrays.asList(
                new Developer("dev1", new BigDecimal("70000"), 33),
                new Developer("dev2", new BigDecimal("170000"), 40),
                new Developer("dev3", new BigDecimal("270000"), 100));


        newline("1");
        Developer d = developersList.stream()
                .filter(x -> "dev2".equals(x.getName()) && x.getAge() > 35)
                .findFirst()
                .orElse(new Developer("aaaaaa", new BigDecimal("111111111"), 200));
        System.out.println(d);

        newline("2");
        BigDecimal bd = developersList.stream()
                .filter(x -> "dev2".equals(x.getName()) && x.getAge() > 35)
                .map(Developer::getMoney)
                .findFirst()
                .orElse(null);
        System.out.println(bd);

        newline("2'");
        Developer bd2 = developersList.stream()
                .filter(x -> "dev2".equals(x.getName()) && x.getAge() > 35)
                .findFirst()
                .orElse(null);
        System.out.println(bd2);

        newline("2''");
        Stream<String> names = Stream.of("aBc", "d", "ef", "42342", "111");
        System.out.println(
                names
                        .map(s -> {
                            return s.toUpperCase();
                        })
                        .sorted(Comparator.reverseOrder())
                        .collect(Collectors.toList()));

        newline("3, super przerobienie jednej listy na druga");
        List<BigDecimal> bdList = developersList.stream().map(Developer::getMoney).collect(Collectors.toList());
        bdList.forEach(i -> System.out.println(i));

        newline("4, super przemapowanie listy jednych obiektow na drugie");
        List<Human> humans = developersList.stream()
                .map(x -> {
                    return new Human(x.getName(), x.getAge());
                })
                .collect(Collectors.toList());
        System.out.println(humans);

        newline("5, robi ze stream Array");
        Stream<Integer> intStream = Stream.of(1, 2, 3, 4);
        Integer[] intArray = intStream.toArray(Integer[]::new);
        System.out.println(Arrays.toString(intArray)); //prints [1, 2, 3, 4]

        newline("6, sortujemy");
        developersList.forEach(System.out::print);
        System.out.println();
        developersList.stream().sorted((o1, o2) -> o2.getAge() - o1.getAge()).forEach(System.out::print);

        developersList.sort((o1, o2) -> o2.getAge() - o1.getAge());

    }

    public void newline(String line) {
        System.out.println("\n_____________" + line + "_____________");
    }

}
