package pl.com.hedgo.java8.mojintfunk;

@FunctionalInterface
public interface Process {
    public String wykonaj(String text, Integer myint);
}
