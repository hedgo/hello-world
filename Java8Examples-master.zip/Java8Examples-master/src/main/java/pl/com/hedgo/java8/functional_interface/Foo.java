package pl.com.hedgo.java8.functional_interface;

@FunctionalInterface   //optional, ale pilnuje zeby nie dodawac innych metod abstrakcyjnych
public interface Foo {
    String method(String string, Integer myint);
    default String methodDefault(String string) {return string + "a tutaj text z metody default:)";}; //default mowi, ze metoda bedzie implementowana w interfejsie:) nie powinno byc naduzywane!!
    static String methodStatic(String string) {return  string+" z metody statycznej z interfejsu.. nice:)";};
}
