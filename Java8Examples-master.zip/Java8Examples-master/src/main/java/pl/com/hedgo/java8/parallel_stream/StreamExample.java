package pl.com.hedgo.java8.parallel_stream;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class StreamExample {

    public static void main(String[] args) {

        List<Integer> myList = new ArrayList<>();

        for(int i=1; i<=100; i++) myList.add(i);

        myList.forEach(System.out::println);

        Stream<Integer> seqStream = myList.stream();

        Stream<Integer> parallelStream = myList.parallelStream();

        //using lambda with Stream API, filter example
        Stream<Integer> highNums = parallelStream.filter(p -> p > 90);
        highNums.forEach(p -> System.out.println("High Nums parallel="+p));

        Stream<Integer> highNumsSeq = seqStream.filter(p -> p > 90);
        highNumsSeq.forEach(p -> System.out.println("High Nums sequential="+p));
        //highNumsSeq.forEach(System.out::print);

        LocalTime time = LocalTime.now();
        System.out.println("Current Time="+time);

    }
}
