package com.example.eurekaservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@EnableDiscoveryClient
@RestController
@RefreshScope    //dla odswiezania
public class EurekaserviceApplication {

	@Value("${service.instance.name}") private String instance;

//	Wartosci pobierane z Config Servera w fazie poczatkowej startu aplikacji
	@Autowired private ConfigClientAppConfiguration properties;
	@Value("${some.other.property}") private String someOtherProperty;

	public static void main(String[] args) {
		SpringApplication.run(EurekaserviceApplication.class, args);
	}

	@RequestMapping("/")
	public String message(){
		StringBuilder sb = new StringBuilder();
		sb.append(properties.getProperty());
		sb.append(" || ");
		sb.append(someOtherProperty);
		return "Hello from "+instance + " PROPERTY FROM CONFIG SERVER=[" +sb.toString()+"]"; }

}

