package com.example.microserviceclient;

import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@EnableDiscoveryClient
@SpringBootApplication
@RestController
//@RibbonClient(name="my-service-lb")    //a tutaj jeszcze potrzebne do Ribbon BEZ discovery, tylko podajemy liste serwerow w XML
public class MicroserviceclientApplication {
    @Autowired private EurekaClient eurekaClient;
    @Autowired private RestTemplateBuilder restTemplateBuilder;
    @Autowired private RestTemplate restTemplateWithRibbonLB;

    public static void main(String[] args) {
        SpringApplication.run(MicroserviceclientApplication.class, args);
    }

    @RequestMapping("/")
    public String callService() {
        System.out.println("callService");
        RestTemplate restTemplate = restTemplateBuilder.build();
        InstanceInfo instanceInfo = eurekaClient.getNextServerFromEureka("service", false);
        String baseUrl = instanceInfo.getHomePageUrl();
        ResponseEntity<String> response = restTemplate.exchange(baseUrl, HttpMethod.DELETE.GET, null, String.class);
        return response.getBody();
    }

    @RequestMapping("/ribbon")
    public String callServiceRibbonLB() {
        System.out.println("callServiceRibbonLB");
        return restTemplateWithRibbonLB.getForEntity("http://service", String.class).getBody();
    }

//    Genialne!!!:)
    @Bean @LoadBalanced public RestTemplate restTemplateRibbon() { return new RestTemplate(); }
}

