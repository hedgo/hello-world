import {Component, OnInit} from '@angular/core';
import {trigger, style, transition, animate, keyframes, query, stagger} from '@angular/animations';
import {DataService} from '../data.service';

/*AO tu dwie kropeczki*/

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  animations: [
    trigger('goals', [
      transition('* => *', [
        query(':enter', style({opacity: 0}), {optional: true}),

        query(':enter', stagger('300ms', [
          animate('.6s ease-in', keyframes([
            style({opacity: 0, transform: 'translate(-75%)', offset: 0}),
            style({opacity: 0.5, transform: 'translate(35px)', offset: .3}),
            style({opacity: 1, transform: 'translate(0)', offset: 1})
          ]))]), {optional: true}),

        query(':leave', stagger('300ms', [
          animate('.6s ease-in', keyframes([
            style({opacity: 1, transform: 'translate(0)', offset: 0}),
            style({opacity: 0.5, transform: 'translate(35px)', offset: .3}),
            style({opacity: 0, transform: 'translate(-75%)', offset: 1})
          ]))]), {optional: true})
      ])
    ])
  ]
})
export class HomeComponent implements OnInit {

  itemCount: number = 4;
  btnText: string = 'Add an item my friend';
  goalText: string = 'My first life goal !!!';
  goals = ['My first life goal', 'I want to swim butterfly', 'Win QC'];

  constructor(private _data: DataService) {
  }

  ngOnInit() {
    this._data.goal.subscribe(res => this.goals = res);
    this.itemCount = this.goals.length;
    this._data.changeGoal(this.goals);/*AO ?*/
  }


  addItem() {/*Obsluguje event click na przycisku submit. Nice:)*/
    this.goals.push(this.goalText);
    this.goalText = '';
    this.itemCount = this.goals.length;
    this._data.changeGoal(this.goals);/*AO ?*/

  }

  removeItem(i) {
    this.goals.splice(i, 1);
    this._data.changeGoal(this.goals);/*AO ?*/
  }

}
