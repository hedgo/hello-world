package coba.passat.domains.authorization;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MyRepoJPA extends JpaRepository<Customer, Long> {

    /*Based on https://www.springbyexample.org/examples/spring-data-jpa-repository.html*/

    //1. Convention naming example
    List<Customer> findByName(String name);

    List<Customer> findByNameLike(String name);

    List<Customer> findByRole(String role);

    //2. JPQL expample
    @Query("Select a from Customer a where a.name like :param_name%")
    List<Customer> findByMojaNazwaJQL(@Param("param_name") String param_name);

    //3. Native expample
    @Query(value = "Select * FROM CLIENT_SYSTEMS_AV where DB_NAME = 'K_12' and ROLE_PREFIX=:param_role_prefix", nativeQuery = true)
    List<Customer> findByMojaNazwaNative(@Param("param_role_prefix") String param_role_prefix);

    //4. Page Query example
    //Trzeba wtedy dodac parametr Pageable
/*    @Query(FIND_BY_ADDRESS_QUERY)
    public Page<Person> findByAddress(@Param("address") String address, Pageable page);*/

    //5. Native expample in ORM.XML
    @Query(name="Moja")
    List<Customer> findSthByOrmFile(@Param("param_name") String param_name);

}

