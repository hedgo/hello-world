package coba.passat.domains.authorization.annotations;

import org.springframework.stereotype.Component;

@Component
public @interface BusinessObject {
}
