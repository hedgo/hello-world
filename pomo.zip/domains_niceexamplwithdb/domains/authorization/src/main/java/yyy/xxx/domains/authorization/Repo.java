package coba.passat.domains.authorization;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Component
public class Repo {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private NamedParameterJdbcTemplate jdbcTemplateNamed;


    public String myFirstFunction(Integer wiek) {

        System.out.println("Repo: myFirstFunction called!");
        String SELECT_ALL_SQL = "Select * FROM CLIENT_SYSTEMS_AV";

        List<Map<String, Object>> allUsers = jdbcTemplate.queryForList(SELECT_ALL_SQL);

        List<User> userList = new ArrayList<User>();

        for (Map row : allUsers) {
            userList.add(new User((String) row.get("NAME"), (String) row.get("ROLE_PREFIX")));
        }


        System.out.println("userList !!! =" + userList);


        return "";
    }

}

class User {
    private String name;
    private String role;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public User(String name, String role) {
        this.name = name;
        this.role = role;
    }

    @Override
    public String toString() {
        return "User{" +
                "name='" + name + '\'' +
                ", role='" + role + '\'' +
                '}';
    }
}

