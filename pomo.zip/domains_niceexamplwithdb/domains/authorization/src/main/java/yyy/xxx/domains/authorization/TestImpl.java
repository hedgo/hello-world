package coba.passat.domains.authorization;

import coba.passat.domains.authorization.annotations.BusinessUseCase;
import org.springframework.beans.factory.annotation.Autowired;

@BusinessUseCase
public class TestImpl implements Test {
    @Autowired Repo repo;
    @Autowired MyRepoJPA myRepoJPA;

    @Override
    public void myTest() {

        repo.myFirstFunction(1);
        System.out.println("_______________________________");
        System.out.println(myRepoJPA.findAll());
        System.out.println("_______________________________");
        System.out.println(myRepoJPA.findByName("S"));
        System.out.println("_______________________________");
        System.out.println(myRepoJPA.findByNameLike("S%"));
        System.out.println("_______________________________");
        System.out.println(myRepoJPA.findByRole("H"));
        System.out.println("_______________________________");
        System.out.println(myRepoJPA.findByMojaNazwaJQL("K"));
        System.out.println("_______________________________");
        System.out.println(myRepoJPA.findByMojaNazwaNative("VKAaa"));
        System.out.println("_______________________________");
        //Update
        Customer customer = myRepoJPA.findOne(Long.valueOf(13));
        System.out.println(customer);
        customer.setName("RST");
        myRepoJPA.saveAndFlush(customer);
        System.out.println("_______________________________");
        System.out.println(myRepoJPA.findSthByOrmFile("S"));
        System.out.println("_______________________________");

    }
}
