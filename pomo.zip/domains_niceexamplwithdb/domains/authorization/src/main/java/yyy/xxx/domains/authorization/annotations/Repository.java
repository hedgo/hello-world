package coba.passat.domains.authorization.annotations;


@org.springframework.stereotype.Repository
public @interface Repository {
}
