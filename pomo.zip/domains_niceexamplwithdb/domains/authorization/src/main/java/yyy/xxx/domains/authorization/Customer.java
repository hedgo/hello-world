package coba.passat.domains.authorization;

import javax.persistence.*;


//Tu zdecydowanie przydalby sie lombok!

@Entity
@Table(name = "sometable")
class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "KEY")
    private Long id;

    @Column(name = "NAME")
    private String name;

    @Column(name = "ROLE_PREFIX")
    private String role;

    @Column(name = "APPLICATION")
    private String application;

    @Column(name = "DB_NAME")
    private String db_name;

    @Column(name = "EMAIL_OK")
    private String emailOk;

    @Column(name = "EMAIL_ERROR")
    private String emailError;

    public Customer() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getApplication() {
        return application;
    }

    public void setApplication(String application) {
        this.application = application;
    }

    public String getDb_name() {
        return db_name;
    }

    public void setDb_name(String db_name) {
        this.db_name = db_name;
    }

    public String getEmailOk() {
        return emailOk;
    }

    public void setEmailOk(String emailOk) {
        this.emailOk = emailOk;
    }

    public String getEmailError() {
        return emailError;
    }

    public void setEmailError(String emailError) {
        this.emailError = emailError;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", role='" + role + '\'' +
                ", application='" + application + '\'' +
                ", db_name='" + db_name + '\'' +
                ", emailOk='" + emailOk + '\'' +
                ", emailError='" + emailError + '\'' +
                '}';
    }
}

