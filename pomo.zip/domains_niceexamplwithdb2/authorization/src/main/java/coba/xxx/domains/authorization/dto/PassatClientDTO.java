package coba.passat.domains.authorization.dto;

import com.commerzbank.frame.architecture.crud.RestDTO;

import java.io.Serializable;


public class PassatClientDTO implements Serializable, RestDTO<Integer> {
    /**
     * Generated suid.
     */
    private static final long serialVersionUID = 3588639399102659476L;

    /**
     * Version.
     */
    private Integer version;

    /**
     * The id of the account.
     */
    private Long id;

    /**
     * The balance of the account.
     */
    private String name;

    /**
     * The interest rate for the account received by the resp. service.
     */
    private String email;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public Integer getResourceId() {
        return Integer.valueOf(id.toString());
    }

    @Override
    public void setResourceId(Integer id) {
        this.id = new Long(id);
    }

    public Integer getVersion() {
        return this.version;
    }

    public void setVersion(final Integer version) {
        this.version = version;
    }
}
