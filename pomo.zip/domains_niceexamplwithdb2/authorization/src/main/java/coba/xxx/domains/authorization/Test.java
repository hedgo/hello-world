package coba.passat.domains.authorization;

public interface Test {
    public void myTest();
}
