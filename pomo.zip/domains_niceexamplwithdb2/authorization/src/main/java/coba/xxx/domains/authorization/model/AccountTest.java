package coba.passat.domains.authorization.model;

import framex.meta.beans.DomainModel;
import framex.meta.persistence.Versioned;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.annotations.Entity;
import org.springframework.data.annotation.Id;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Version;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * This Java class file was generated from FAPP model "domain.fapp" 
 * at Wed Mar 21 13:23:03 CET 2018.
 * 
 * 
 */
@DomainModel
@Versioned
@Entity
@Generated(value = "xxx", date = "2018-03-21T13:23+0100")
@SuppressWarnings("all")
public class AccountTest implements xxx.model.Versioned<Integer>, Serializable {
    /**
     * Generated UUID.
     */
    private static final long serialVersionUID = 303823567L;

    @GeneratedValue
    @Column(name = "ID")
    @Id
    private Integer accountId;

    /**
     * Getter for accountId.
     * @return accountId - get value for accountId.
     */
    public Integer getAccountId() {
        return this.accountId;
    }

    /**
     * Setter for accountId.
     * @param accountId - set value for accountId.
     */
    public void setAccountId(final Integer accountId) {
        this.accountId = accountId;
    }

    private BigDecimal balance;

    /**
     * Getter for balance.
     * @return balance - get value for balance.
     */
    public BigDecimal getBalance() {
        return this.balance;
    }

    /**
     * Setter for balance.
     * @param balance - set value for balance.
     */
    public void setBalance(final BigDecimal balance) {
        this.balance = balance;
    }

    private BigDecimal interestRate;

    /**
     * Getter for interestRate.
     * @return interestRate - get value for interestRate.
     */
    public BigDecimal getInterestRate() {
        return this.interestRate;
    }

    /**
     * Setter for interestRate.
     * @param interestRate - set value for interestRate.
     */
    public void setInterestRate(final BigDecimal interestRate) {
        this.interestRate = interestRate;
    }

    public AccountTest() {
    }

    @Version
    private Integer version;

    public Integer getVersion() {
        return this.version;
    }

    public void setVersion(final Integer version) {
        this.version = version;
    }

    /**
     * Constructor with all attributes
     * @param accountId the accountId
     * @param balance the balance
     * @param interestRate the interestRate
     * @param customers the customers
     * @param transactions the transactions
     * @param representatives the representatives
     *
     */
    public AccountTest(final Integer accountId, final BigDecimal balance, final BigDecimal interestRate) {
        this.accountId = accountId;
        this.balance = balance;
        this.interestRate = interestRate;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 31 * hash + (null == accountId ? 0 : accountId.hashCode());
        return hash;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
        	return true;
        }
        if ((obj == null) || (obj.getClass() != this.getClass())) {
        	return false;
        }
        
        AccountTest test = (AccountTest) obj;
        
        return
        	(accountId == test.getAccountId() || (accountId != null && accountId.equals(test.getAccountId())));
    }
    
    /**
     * {@inheritDoc}
     */
   @Override
    public String toString() {
        ReflectionToStringBuilder rsb = new ReflectionToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE);
        rsb.setAppendStatics(false);
        rsb.setAppendTransients(true);
        rsb.setExcludeFieldNames("customers", "transactions", "representatives");
        return rsb.toString();
    }
    
    /**
     * Helper method to return the entity key.
     * @return The entity key.
     */
    public Integer retrieveKey() {
        return this.accountId;
    }
}
