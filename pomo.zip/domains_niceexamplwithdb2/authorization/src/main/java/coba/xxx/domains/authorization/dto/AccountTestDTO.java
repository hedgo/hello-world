package coba.passat.domains.authorization.dto;

import com.commerzbank.frame.architecture.crud.RestDTO;

import java.io.Serializable;
import java.math.BigDecimal;

public class AccountTestDTO implements Serializable, RestDTO<Integer> {
	/** Generated suid. */
	private static final long serialVersionUID = 3588639399102659476L;

	/** Version. */
	private Integer version;

	/** The id of the account. */
	private Integer id;

	/** The balance of the account. */
	private BigDecimal balance;

	/** The interest rate for the account received by the resp. service. */
	private BigDecimal interestRate;

	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	public BigDecimal getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(BigDecimal interestRate) {
		this.interestRate = interestRate;
	}

	@Override
	public Integer getResourceId() {
		return id;
	}

	@Override
	public void setResourceId(Integer id) {
		this.id = id;
	}

	public Integer getVersion() {
		return this.version;
	}

	public void setVersion(final Integer version) {
		this.version = version;
	}
}
