package coba.passat.domains.authorization;

import coba.passat.domains.authorization.annotations.BusinessUseCase;
import coba.passat.domains.authorization.model.PassatClient;
import org.springframework.beans.factory.annotation.Autowired;

@BusinessUseCase
public class TestImpl implements Test {
    @Autowired Repo repo;
    @Autowired
    PassatClientDAO passatClientDAO;

    @Override
    public void myTest() {

        repo.myFirstFunction(1);
        System.out.println("_______________________________");
        System.out.println(passatClientDAO.findAll());
        System.out.println("_______________________________");
        System.out.println(passatClientDAO.findByName("Ss"));
        System.out.println("_______________________________");
        System.out.println(passatClientDAO.findByNameLike("S%"));
        System.out.println("_______________________________");
        System.out.println(passatClientDAO.findByRole("H_ND"));
        System.out.println("_______________________________");
        System.out.println(passatClientDAO.findByMojaNazwaJQL("K"));
        System.out.println("_______________________________");
        System.out.println(passatClientDAO.findByMojaNazwaNative("VssssKA"));
        System.out.println("_______________________________");
        //Update
        PassatClient passatClient = passatClientDAO.findOne(Long.valueOf(13));
        System.out.println(passatClient);
        passatClient.setName("RST");
        passatClientDAO.saveAndFlush(passatClient);
        System.out.println("_______________________________");
        //System.out.println(passatClientDAO.findSthByOrmFile("Ss"));
        System.out.println("_______________________________");

    }
}
