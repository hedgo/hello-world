package coba.passat.domains.authorization;

import coba.passat.domains.authorization.model.PassatClient;
import com.commerzbank.frame.repository.JpaCrudRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PassatClientDAO extends JpaCrudRepository<PassatClient, Long> {

    /*Based on https://www.springbyexample.org/examples/spring-data-jpa-repository.html*/

    //1. Convention naming example
/*    List<PassatClient> findByName(String name);

    List<PassatClient> findByNameLike(String name);

    List<PassatClient> findByRole(String role);*/

    //2. JPQL expample
/*    @Query("Select a from PassatClient a where a.name like :param_name%")
    List<PassatClient> findByMojaNazwaJQL(@Param("param_name") String param_name);

    //3. Native expample
    @Query(value = "Select * FROM CLIENT_SYSTEMS_AV where DB_NAME = 'k_12' and ROLE_PREFIX=:param_role_prefix", nativeQuery = true)
    List<PassatClient> findByMojaNazwaNative(@Param("param_role_prefix") String param_role_prefix);*/

    //4. Page Query example
    //Trzeba wtedy dodac parametr Pageable
/*    @Query(FIND_BY_ADDRESS_QUERY)
    public Page<Person> findByAddress(@Param("address") String address, Pageable page);*/

    //5. Native expample in ORM.XML
/*    @Query(name="Moja")
    List<PassatClient> findSthByOrmFile(@Param("param_name") String param_name);*/

}

