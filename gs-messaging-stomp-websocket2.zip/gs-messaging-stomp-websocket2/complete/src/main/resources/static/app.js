var stomp = null;

function setConnected(connected) {
    $("#connect").prop("disabled", connected);
    $("#disconnect").prop("disabled", !connected);
    if (connected) {
        $("#conversation").show();
    }
    else {
        $("#conversation").hide();
    }
    $("#greetings").html("");
}

function connect() {
    var socket = new SockJS('/gs-guide-websocket');
    stomp = Stomp.over(socket);
    stomp.connect({},
        function (frame) {
            setConnected(true);
            console.log('Connected: ' + frame);

            stomp.subscribe('/topic/chatroom*', function (incoming) {handleChatroom(incoming);});

            //stomp.subscribe('/topic/chatroom2', function (received_data) {onMsg_chatroom2(JSON.parse(received_data.body).content);});
            stomp.subscribe('/user/' + username + '/reply', function (incoming) {handlePrivateMsg(incoming);});

            stomp.subscribe('/topic/spam_data', function (received_data) {
                onSpam_data(JSON.parse(received_data.body).content);
            })

            stomp.subscribe('/topic/spam_data2', function (received_data) {
                onSpam_data2(received_data);
            });
        });
}

function disconnect() {
    if (stomp != null) {
        stomp.disconnect();
    }
    setConnected(false);
    console.log("Disconnected");
}

function sendUserMsg() {
    if ($("#receiver").val() == '') {
        console.log("Send to topic");
        var paylod = {
            "sender": username,
            "receiver": $('.nav-tabs .active').text(),
            "message": $("#message").val()
        };
        stomp.send("/app/usermsg", {}, JSON.stringify(paylod));



        //!!!!!!!!!! stomp.send("/user/u1/reply", {}, JSON.stringify({ "content": "teeeeeeeeeeeeeeeest!"}));
    }
    else {
        console.log("Send to user");
        var xhttp = new XMLHttpRequest();
        var payload =
            {
                "sender": username,
                "receiver": $("#receiver").val(),
                "message": $("#message").val()
            };


        console.log("WYSYLAM "+JSON.stringify(payload));

        xhttp.open("POST", "http://127.0.0.1:8080/callme", false);//dTE6cHUx
        xhttp.setRequestHeader("Content-type", "application/json");
        xhttp.setRequestHeader('Authorization', 'Basic ' + window.btoa('u111:pu1'));
        xhttp.send(JSON.stringify(payload));
    }
}


function handleChatroom(incoming)
{
    console.log('Received1: '+ incoming);
    console.log('Received2: '+ incoming.body);
    console.log('333: '+ JSON.parse(incoming.body).receiver);

    //SUPER: $("#"+JSON.parse(incoming.body).receiver).append("<tr><td>" + JSON.parse(incoming.body).message + "</td></tr>");

    var template = Handlebars.compile($("#message-sent").html());
    $('.messages-placeholder-'+JSON.parse(incoming.body).receiver).append(template(JSON.parse(incoming.body)));

}

function onMsg_chatroom1(incoming) {
    //$("#chatroom1").append("<tr><td>" + msg + "</td></tr>");
        console.log('Received1: '+ incoming);
        console.log('Received2: '+ incoming.body);

        var template = Handlebars.compile($("#message-sent").html());
        $('.messages-placeholder').append(template(JSON.parse(incoming.body)));
}

/*
function onMsg_chatroom2(msg) {
    $("#chatroom2").append("<tr><td>" + msg + "</td></tr>");
}
*/

function handlePrivateMsg(incoming) {
    $("#priv_notifications").append("<tr><td>" + JSON.parse(incoming.body).message + "</td></tr>");
}

function onSpam_data(msg) {
    $("#spam_data").html("<tr><td>" + msg + "</td></tr>");
    //mytemp();

    var data = {
        users: [{
            person: {
                firstName: "Garry",
                lastName: "Finch"
            },
            jobTitle: "Front End Technical Lead",
            twitter: "gazraa"
        }, {
            person: {
                firstName: "Garry",
                lastName: "Finch"
            },
            jobTitle: "Photographer",
            twitter: "photobasics"
        }, {
            person: {
                firstName: "Garry",
                lastName: "Finch"
            },
            jobTitle: "LEGO Geek",
            twitter: "minifigures"
        }]
    };


    mytemp2(data);
}

function onSpam_data2(received_data) {
    //JSON.parse(received_data.body).content
    //console.log("Received!!! :"+received_data.body);

    var nextdata = JSON.parse(received_data.body);
    mytemp2(nextdata);
}

function mytemp() {
    var data = {"name": "Ritesh Kumar!!!!", "occupation": "developer"};
    var template = Handlebars.compile($('#handlebars-demo').html());
    $(document.body).append(template(data));
}


function mytemp2(data) {

    console.log('Received1: '+ data);
    console.log('Received2: '+ JSON.stringify(data));
    console.log('Received3: '+ eval(data));

    var template = Handlebars.compile($("#some-template").html());

    Handlebars.registerHelper('fullName', function (person) {
        return person.firstName + " " + person.lastName;
    });


    $('.content-placeholder').html(template(data));// $(document.body).prepend(template(data));
}


$(function () {
    $("form").on('submit', function (e) {
        e.preventDefault();
    });
    $("#connect").click(function () {
        connect();
    });
    $("#disconnect").click(function () {
        disconnect();
    });
    $("#send").click(function () {
        sendUserMsg();
    });
    $("#startspam").click(function () {
        var xhttp = new XMLHttpRequest();
        xhttp.open("GET", "http://127.0.0.1:8080/startspam", true);
        xhttp.setRequestHeader('Authorization', 'Basic ' + window.btoa('u1:pu1'));
        xhttp.send();
    })
    $("#startspam2").click(function () {
        var xhttp = new XMLHttpRequest();
        xhttp.open("GET", "http://127.0.0.1:8080/startspam2", true);
        xhttp.setRequestHeader('Authorization', 'Basic ' + window.btoa('u1:pu1'));
        xhttp.send();
    })
    $("#stopspam2").click(function () {
        var xhttp = new XMLHttpRequest();
        xhttp.open("GET", "http://127.0.0.1:8080/stopspam2", true);
        xhttp.setRequestHeader('Authorization', 'Basic ' + window.btoa('u1:pu1'));
        xhttp.send();
    })

});
