package hello.model;

import java.util.List;

public class MyUsers {
    private List<MyData> users;

    public MyUsers(List<MyData> users) {
        this.users = users;
    }

    public List<MyData> getUsers() {
        return users;
    }

    public void setUsers(List<MyData> users) {
        this.users = users;
    }
}
