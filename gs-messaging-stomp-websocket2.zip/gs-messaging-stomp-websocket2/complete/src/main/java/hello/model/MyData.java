package hello.model;

import java.util.List;

public class MyData {
    private Person person;
    private String jobTitle;
    private String twitter;

    public MyData() {
    }

    public MyData(Person person, String jobTitle, String twitter) {
        this.person = person;
        this.jobTitle = jobTitle;
        this.twitter = twitter;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getTwitter() {
        return twitter;
    }

    public void setTwitter(String twitter) {
        this.twitter = twitter;
    }
}
