package hello.util;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class RandomStrings {
    private static final String CHAR_LIST = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
    private static final int RANDOM_STRING_LENGTH = 10;
    private static Random random = new Random();


    public static String generateString(int length)
    {
        char[] text = new char[length];
        for (int i = 0; i < length; i++)
        {
            text[i] = CHAR_LIST.charAt(random.nextInt(CHAR_LIST.length()));
        }
        return new String(text);

    }

    public static int generateInt() {
        return ThreadLocalRandom.current().nextInt(Integer.MIN_VALUE, Integer.MAX_VALUE);
    }

}
