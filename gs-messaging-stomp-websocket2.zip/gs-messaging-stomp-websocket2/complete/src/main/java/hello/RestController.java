package hello;

import hello.model.*;
import hello.util.RandomStrings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessageSendingOperations;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@org.springframework.web.bind.annotation.RestController
public class RestController {

    @Autowired
    private SimpMessageSendingOperations messaging;

    boolean spamActive = false;

    @PostMapping("/callme")
    public void callme(Principal _principal, @RequestBody UserMessage _userMessage) {
        System.out.println("Called by user: "+_principal.getName());
        System.out.println(_userMessage);
//        messaging.convertAndSendToUser(_userMessage.getReceiver(), "/reply", new Greeting(_principal.getName() + ":" + _userMessage.getMessage()));
        messaging.convertAndSendToUser(_userMessage.getReceiver(), "/reply", _userMessage);
    }













    @GetMapping("/callall")
    public void callall(Principal principal) {
        messaging.convertAndSend("/topic/chatroom1", new Greeting(principal.getName() + ":callall"));
    }

    @GetMapping("/startspam")
    public void startspam(Principal principal) {
        for (int i = 0; i < 3; i++) {
            System.out.printf("startspam" + i);
            messaging.convertAndSend("/topic/spam_data", new Greeting(principal.getName() + ":spam " + i));
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }


    @GetMapping("/startspam2")
    public void startspam2(Principal principal) {
        spamActive=true;
        while(spamActive) {
            List<MyData> myDataList = new ArrayList<>();

            for (int j = 0; j < new Random().nextInt(10)+1; j++) {
                myDataList.add(new MyData(new Person("Andrzej1", "Okon1"), "" + RandomStrings.generateInt(), RandomStrings.generateString(20)));
            }

            messaging.convertAndSend("/topic/spam_data2", new MyUsers(myDataList));

            try {
                Thread.sleep(400);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            System.out.println("startspam2 spamactive"+spamActive);
        }


    }

    @GetMapping("/stopspam2")
    public void stopspam2(Principal principal) {

        spamActive=false;
        System.out.println("stopspam2 spamactive"+spamActive);

    }




}
