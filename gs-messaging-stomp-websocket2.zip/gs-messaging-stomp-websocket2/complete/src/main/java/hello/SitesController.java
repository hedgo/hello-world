package hello;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Map;

@Controller
public class SitesController {

    @RequestMapping("/welcome")
    public String welcome(Map<String,Object> model) {
        model.put("message", "QC rules!");
        return "welcome";
    }

    @RequestMapping("/")
    public String slash() {
        return "home";
    }

    @RequestMapping("/index")
    public String index() {
        return "index";
    }

    @RequestMapping("/przelew")
    public String przelew() {
        return "przelew";
    }

    @RequestMapping("/hello")
    public String hello() {
        return "hello";
    }


    @RequestMapping("/login")
    public String login() {
        return "login";
    }

}
