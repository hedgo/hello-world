package hello;

import hello.model.Greeting;
import hello.model.UserMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessageSendingOperations;
import org.springframework.stereotype.Controller;

import java.security.Principal;

@Controller
public class GreetingController {

    @Autowired
    private SimpMessageSendingOperations messaging;

    @MessageMapping("/usermsgold")
    @SendTo("/topic/chatroom1")
    public Greeting greeting(Principal principal, UserMessage userMessage) throws Exception {
        System.out.printf("principal.getName()="+principal.getName());
        //Thread.sleep(1000); // simulated delay
        return new Greeting("Hello, " + userMessage.getMessage() + "!!!"+ userMessage.getReceiver() /*+principal.getName()*/);
    }

    @MessageMapping("/usermsg")
    public void usermsg(Principal _principal, UserMessage _userMessage) throws Exception {
        messaging.convertAndSend("/topic/"+ _userMessage.getReceiver(),_userMessage);
    }

}
