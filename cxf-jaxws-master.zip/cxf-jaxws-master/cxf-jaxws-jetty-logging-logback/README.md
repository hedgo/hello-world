# cxf-jaxws-jetty-logging-logback

[![Quality Gate](https://sonarcloud.io/api/badges/gate?key=com.codenotfound:cxf-jaxws-jetty-logging-logback)](https://sonarcloud.io/dashboard/index/com.codenotfound:cxf-jaxws-jetty-logging-logback)

A detailed example on how to setup CXF to log request and response SOAP messages using the Logback logging framework.

[https://www.codenotfound.com/jaxws-cxf-log-request-response-soap-messages-logback.html](https://www.codenotfound.com/jaxws-cxf-log-request-response-soap-messages-logback.html)
