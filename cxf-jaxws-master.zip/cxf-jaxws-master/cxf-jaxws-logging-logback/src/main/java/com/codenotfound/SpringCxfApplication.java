package com.codenotfound;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
public class SpringCxfApplication extends SpringBootServletInitializer {

  public static void main(String[] args) {
    SpringApplication.run(SpringCxfApplication.class, args);
  }
}
