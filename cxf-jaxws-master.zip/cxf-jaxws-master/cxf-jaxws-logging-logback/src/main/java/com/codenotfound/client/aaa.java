@DomainFactory
public class OrderFactory {
    @Inject private RebatePolicyFactory rebatePolicyFactory;

    public Order crateOrder(Client client) throws OrderCreationException {
        checkIfclientCanPerformPurchase(client);
        Order order = new Order(client, Money.ZERO, OrderStatus.DRAFT);
        RebatePolicy rebatePolicy = rebatePolicyFactory.createRebatePolicy();
        order.setRebatePolicy(rebatePolicy);
        addGratis(order, client);
        return order;
    }
}