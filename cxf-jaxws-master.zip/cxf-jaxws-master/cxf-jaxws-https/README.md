# cxf-jaxws-https

[![Quality Gate](https://sonarcloud.io/api/badges/gate?key=com.codenotfound:cxf-jaxws-https)](https://sonarcloud.io/dashboard/index/com.codenotfound:cxf-jaxws-https)

A detailed step-by-step tutorial on how to setup HTTPS on client and server side using Apache CXF and Spring Boot.

[https://www.codenotfound.com/cxf-jaxws/](https://www.codenotfound.com/cxf-jaxws/)
