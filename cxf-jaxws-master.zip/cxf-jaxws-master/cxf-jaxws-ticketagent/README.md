# cxf-jaxws-ticketagent

[![Quality Gate](https://sonarcloud.io/api/badges/gate?key=com.codenotfound:cxf-jaxws-ticketagent)](https://sonarcloud.io/dashboard/index/com.codenotfound:cxf-jaxws-ticketagent)

Apache CXF - JAX-WS Ticket Agent project based on the TicketAgent.wsdl example from the [W3C WSDL 1.1 specification](https://www.w3.org/TR/wsdl11elementidentifiers/#Iri-ref-ex).

[https://www.codenotfound.com/cxf-jaxws/](https://www.codenotfound.com/cxf-jaxws/)
