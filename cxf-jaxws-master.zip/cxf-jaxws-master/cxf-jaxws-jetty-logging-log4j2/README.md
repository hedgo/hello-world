# cxf-jaxws-jetty-logging-log4j2

[![Quality Gate](https://sonarcloud.io/api/badges/gate?key=com.codenotfound:cxf-jaxws-jetty-logging-log4j2)](https://sonarcloud.io/dashboard/index/com.codenotfound:cxf-jaxws-jetty-logging-log4j2)

A code sample which shows how to configure CXF to log the request and response SOAP messages using Log4j2.

[https://www.codenotfound.com/jaxws-cxf-logging-request-response-soap-messages-log4j2.html](https://www.codenotfound.com/jaxws-cxf-logging-request-response-soap-messages-log4j2.html)
