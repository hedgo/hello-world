# cxf-jaxws-jetty-logging-log4j

[![Quality Gate](https://sonarcloud.io/api/badges/gate?key=com.codenotfound:cxf-jaxws-jetty-logging-log4j)](https://sonarcloud.io/dashboard/index/com.codenotfound:cxf-jaxws-jetty-logging-log4j)

A code sample which shows how to configure CXF to log the request and response SOAP messages using Log4j.

[https://www.codenotfound.com/jaxws-cxf-logging-request-response-soap-messages-log4j.html](https://www.codenotfound.com/jaxws-cxf-logging-request-response-soap-messages-log4j.html)
