# cxf-jaxws

[![Build Status](https://travis-ci.org/code-not-found/cxf-jaxws.svg?branch=master)](https://travis-ci.org/code-not-found/cxf-jaxws)
[![MIT licensed](https://img.shields.io/badge/license-MIT-blue.svg)](./LICENSE)

This repository contains the source code for the cxf-jaxws examples posted on [https://www.codenotfound.com/cxf-jaxws/](https://www.codenotfound.com/cxf-jaxws/)

In case of questions or remarks please leave a comment in the respective blog post. Thanks!
