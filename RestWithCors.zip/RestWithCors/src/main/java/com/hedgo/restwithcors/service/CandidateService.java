package com.hedgo.restwithcors.service;

import com.hedgo.restwithcors.model.Candidate;
import com.hedgo.restwithcors.repository.CandidateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CandidateService {
    private @Autowired CandidateRepository repository;

    public void addCandidate(Candidate _candidate){
        System.out.println("CandidateService::addCandidate");
        repository.save(_candidate);
    }
}
