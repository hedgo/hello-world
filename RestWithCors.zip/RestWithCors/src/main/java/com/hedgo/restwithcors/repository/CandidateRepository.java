package com.hedgo.restwithcors.repository;
import com.hedgo.restwithcors.model.Candidate;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface CandidateRepository extends MongoRepository<Candidate, String> {
    public Candidate findByFirstName(String firstName);
    public List<Candidate> findByLastName(String lastName);
}
