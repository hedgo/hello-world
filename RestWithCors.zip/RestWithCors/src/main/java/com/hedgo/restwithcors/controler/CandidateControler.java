package com.hedgo.restwithcors.controler;

import com.hedgo.restwithcors.model.Candidate;
import com.hedgo.restwithcors.model.Hero;
import com.hedgo.restwithcors.repository.CandidateRepository;
import com.hedgo.restwithcors.service.CandidateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/candidates")
@CrossOrigin(origins = "http://127.0.0.1:3000")
public class CandidateControler {
    static public List<Candidate> candidatesList = new ArrayList<Candidate>();
    private @Autowired CandidateService service;

    static {
        for (int i = 1; i <= 450000; i++) {
            candidatesList.add(new Candidate("Andy"+i,"Okon"+i,"555555555","andy@a.com"+i,"java"+i,"hired","linkedin"));
        }
/*
        candidatesList.add(new Candidate("Jonny","Rambo","555555555","rambo@power.com","java","hired","linkedin"));
        candidatesList.add(new Candidate("Jan","Kowalski","22222222","kow@power.com","oracle","hired","linkedin"));
        candidatesList.add(new Candidate("Martin","Fowel","111111111","martin@power.com","java","hired","linkedin"));
*/
    }

    @GetMapping
    @ResponseBody
    public List<Candidate> getCandidates(@RequestParam(required = false, defaultValue = "World") String name) {
        System.out.println("getAll start");
        //candidatesList.forEach(System.out::print);
        System.out.println("getAll end");
        return candidatesList;
    }

    @PostMapping
    @ResponseBody
    public Candidate addCandidate(@RequestBody Candidate _candidate) throws Exception {
        System.out.println("CandidateControler::addCandidate");
        candidatesList.add(_candidate);
        service.addCandidate(_candidate);
        return _candidate;
    }
}
