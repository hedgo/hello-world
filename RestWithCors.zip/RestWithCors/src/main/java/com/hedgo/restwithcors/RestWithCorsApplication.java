package com.hedgo.restwithcors;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@SpringBootApplication
@ComponentScan(basePackages = "com.hedgo.restwithcors")
@EnableMongoRepositories(basePackages = "com.hedgo.restwithcors")
public class RestWithCorsApplication {

    public static void main(String[] args) {
        SpringApplication.run(RestWithCorsApplication.class, args);
    }
}
