package com.ensat.services;

import com.ensat.entities.Product;
import com.ensat.repositories.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductServiceImpl implements ProductService {
    @Autowired private ProductRepository productRepository;

    public Iterable<Product> listAll() { return productRepository.findAll(); }

    public Product get(Integer id) { return productRepository.findById(id).get(); }

    public Product save(Product product) {
        return productRepository.save(product);
    }

    public void delete(Integer id) { productRepository.deleteById(id); }
}
