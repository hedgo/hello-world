package com.ensat.services;

import com.ensat.entities.Product;

public interface ProductService {
    Iterable<Product> listAll();
    Product get(Integer id);
    Product save(Product product);
    void delete(Integer id);
}
