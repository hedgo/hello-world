package com.ensat.rest;

import com.ensat.entities.Product;
import com.ensat.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/rest/product")
public class ProductRestController {
    @Autowired private ProductService productService;

    @GetMapping("/all")
    public Iterable<Product> showallprod() {
        return productService.listAll();
    }

    @GetMapping("/{id}")
    public Product showProduct(@PathVariable Integer id) { return productService.get(id); }
}
