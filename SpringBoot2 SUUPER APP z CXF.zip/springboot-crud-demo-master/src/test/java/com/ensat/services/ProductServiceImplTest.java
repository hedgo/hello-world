package com.ensat.services;

import com.ensat.SpringBootWebApplication;
import com.ensat.entities.Product;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

//Full component test without mocks (not simple mocked Unit test)
@RunWith(SpringRunner.class)
@SpringBootTest(classes = SpringBootWebApplication.class)
public class ProductServiceImplTest {
    @Autowired ProductService productService;

    @Test
    public void test_listAllProducts() { productService.listAll().forEach(p -> System.out.println(p)); }

    @Test
    public void test_getProductById() { System.out.println(productService.get(3)); }
}