package com.ensat.ws.service;

import com.ensat.ws.model.Greeting;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class InfoServiceImpl implements InfoService {

	@Override
	public Greeting sayHowAreYou(String name) {
		Greeting greeting = new Greeting();
		greeting.setMessage("How are you " + name + "!!!");
		greeting.setDate(new Date());
		return greeting;
	}
}
