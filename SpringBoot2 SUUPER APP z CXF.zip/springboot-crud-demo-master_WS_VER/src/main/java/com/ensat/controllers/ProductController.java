package com.ensat.controllers;

import com.ensat.entities.Product;
import com.ensat.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/product")
public class ProductController {
    @Autowired private ProductService productService;

    @GetMapping("/all")
    public String list(Model model) {
        model.addAttribute("products", productService.listAll());
        return "products";
    }

    @GetMapping("{id}")
    public String showProduct(@PathVariable Integer id, Model model) {
        model.addAttribute("product", productService.get(id));
        return "productshow";
    }

    @GetMapping("edit/{id}")
    public String edit(@PathVariable Integer id, Model model) {
        model.addAttribute("product", productService.get(id));
        return "productform";
    }

    @GetMapping("new")
    public String newProduct(Model model) {
        model.addAttribute("product", new Product());
        return "productform";
    }

    @PostMapping("")
    public String saveProduct(Product product) {
        productService.save(product);
        return "redirect:/product/" ;//!!!!!!+ product.getId();
    }

    @GetMapping("delete/{id}")
    public String delete(@PathVariable Integer id) {
        productService.delete(id);
        return "redirect:/product/all";
    }
}
