package hello;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessageSendingOperations;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@org.springframework.web.bind.annotation.RestController
public class RestController {

    @Autowired
    private SimpMessageSendingOperations messaging;

    @GetMapping("/makecall")
    public void makecall()
    {
        System.out.printf("makecall2() start");
        messaging.convertAndSend("/topic/greetings",new Greeting("QC rules!!!"));
        System.out.printf("makecall2() end");
    }

}
