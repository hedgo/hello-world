import { Component, OnInit } from '@angular/core';
import { Candidate }    from '../../model/candidate';
import { CandidateService }         from '../../services/candidate.service';
import { LocalDataSource } from 'ng2-smart-table';

@Component({
    selector: 'search-form',
    templateUrl: './search-form.component.html',
    providers: [CandidateService]
})
export class SearchFormComponent implements OnInit {
    candidates:Candidate[] = [];

    settings = {
        add: {
            //addButtonContent: '<button type="button" class="btn btn-default" aria-label="Left Align"><span class="glyphicon glyphicon-align-left" aria-hidden="true"></span></button>',
            addButtonContent: '<button type="button" class="btn btn-default"><span class="glyphicon glyphicon-plus"/></button>',
            createButtonContent: '<button type="button" class="btn btn-default"><span class="glyphicon glyphicon-ok" aria-hidden="true"></span></button>',
            cancelButtonContent: '<button type="button" class="btn btn-default"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>',
        },
        edit: {
            editButtonContent: '<button type="button" class="btn btn-default"><span class="glyphicon glyphicon-pencil"/></button>',
            saveButtonContent: '<button type="button" class="btn btn-default"><span class="glyphicon glyphicon-ok"/></button></i>',
            cancelButtonContent: '<button type="button" class="btn btn-default"><span class="glyphicon glyphicon-remove"/></button></i>',
        },
        delete: {
            deleteButtonContent: '<button type="button" class="btn btn-default"><span class="glyphicon glyphicon-trash"/></button></i>',
            confirmDelete: true
        },
        columns: {
            firstName: {
                title: 'firstName'//, filter: false
            },
            lastName: {
                title: 'lastName'//, filter: false
            },
            telephone: {
                title: 'telephone'//, filter: false
            },
            email: {
                title: 'email'//, filter: false
            }
        },
        actions: {
            position: 'left'
        }

    };

    /*    data = [
     {
     firstName: "1",
     lastName: "Leanne Graham",
     telephone: "Bret",
     email: "Sincere@april.biz"
     }
     ];*/

    source:LocalDataSource;

    /*    onSearch(query: string = '') {
     this.source.setFilter([
     // fields we want to include in the search
     {
     field: 'firstName',
     search: query
     },
     {
     field: 'lastName',
     search: query
     },
     {
     field: 'telephone',
     search: query
     },
     {
     field: 'email',
     search: query
     }
     ], false);
     }*/


    constructor(private service:CandidateService) {
    }

    ngOnInit() {
/*        this.service.getCandidates().then(candidates => {
            this.candidates = candidates;
            this.source = new LocalDataSource(this.candidates);
        });*/
        //console.log("ngOnInit->getHeroes=" + JSON.stringify(this.candidates));
    }


    clearCandidates(){
        this.candidates = [];
        this.source = new LocalDataSource(this.candidates);
    }


    searchCandidates() {
        this.service.getCandidates().then(candidates => this.candidates = candidates);
        this.source = new LocalDataSource(this.candidates);
        //console.log("searchCandidates->getHeroes=" + JSON.stringify(this.candidates));
    }

/*    onDeleteConfirm(event):void {
        if (window.confirm('Are you sure you want to delete?')) {
            event.confirm.resolve();
        } else {
            event.confirm.reject();
        }
    }*/


}
