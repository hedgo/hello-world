import { Component, OnInit } from '@angular/core';
import { Candidate }    from '../../model/candidate';
import { CandidateService }         from '../../services/candidate.service';

@Component({
    selector: 'candidate-form',
    templateUrl: './candidate-form.component.html'
})
export class CandidateFormComponent implements OnInit {
    profiles = ['java', 'oracle', 'unix', 'esbase'];
    statuses = ['put away', 'to connect', 'to contact phone', 'to contact f2f', 'contacted phone', 'contacted f2f', 'hired'];
    sources = ['firma zewnetrzna', 'linkedid', 'goldenline', 'job fair (wpisz)', 'recommendation (wpisz)', 'ogloszenie - pracuj.pl'];
    oneCandidate:Candidate;
    submitted = false;



    constructor(private candidateService:CandidateService) {
    }

    onSubmit() {
        this.submitted = true;
    }

    ngOnInit() {
        this.loadDefaultCandidate();
        console.log(JSON.stringify(this.oneCandidate));
    }

    loadDefaultCandidate() {
        this.oneCandidate = new Candidate('Andrzej', 'Okon', '667758866', 'hedgo@poczta.onet.pl', 'java', 'hired', 'linkedid');
    }

    addCandidate() {
        console.log("addCandidate: " + JSON.stringify(this.oneCandidate));
        this.candidateService.addCandidate(this.oneCandidate);

    }

    showFormControls(form:any) {
        return form && form.controls['name'] &&
            form.controls['name'].value;
    }

}
