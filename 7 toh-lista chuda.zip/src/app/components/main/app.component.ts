import { Component } from '@angular/core';

@Component({
    selector: 'my-app',
    template: `
    <candidate-form></candidate-form>
    <search-form></search-form>
<!--    <hero-list></hero-list>
    <sales-tax></sales-tax>
-->    <!--<hero-form></hero-form>-->
    <!--<example-app></example-app>-->
  `
})
export class AppComponent {
}
