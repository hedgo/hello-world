import { Injectable } from '@angular/core';

import { Candidate } from '../model/candidate';
import { Logger } from '../services/logger.service';

//REST!!
import { Headers, Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class CandidateService {
    private headers = new Headers({'Content-Type': 'application/json'});
    private candidatesUrl = 'http://127.0.0.1:8080/candidates';
    private candidates:Candidate[] = [];

    constructor(private logger:Logger,
                private http:Http) {
    }

    addCandidate(candidate:Candidate):Promise<Candidate> {
        console.log("addCandidate =" + JSON.stringify(candidate));
        const url = `${this.candidatesUrl}`;
        return this.http
            .post(url, JSON.stringify(candidate), {headers: this.headers})
            .toPromise()
            .then(() => candidate)
            .catch(this.handleError);
    }

    getCandidates():Promise<Candidate[]> {
        console.log("getCandidates start");
        return this.http.get(this.candidatesUrl).toPromise()
            .then(response => response.json() as Candidate[])
            .catch(this.handleError);
        //console.log("getCandidates end");
    }


    private handleError(error:any):Promise<any> {
        console.error('An error occurred', error);
        return Promise.reject(error.message || error);
    }
}
