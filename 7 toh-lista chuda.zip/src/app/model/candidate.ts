//let nextId = 1;

export class Candidate {
    //id:number;

    constructor(public firstName:string,
                public lastName:string,
                public telephone?:string,
                public email?:string,
                public profile?:string,
                public status?:string,
                public source?:string,
    ) {
        //this.id = nextId++;
    }
}
